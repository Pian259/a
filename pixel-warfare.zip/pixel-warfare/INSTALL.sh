#!/usr/bin/env bash
set -euo pipefail
"$(dirname "$0")/scripts/install.sh"
