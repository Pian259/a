// Socket.IO lobby lifecycle is implemented in main.js; authoritative input/state in Game and server/game.js.
