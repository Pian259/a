// Keyboard, mouse and touch input handlers are implemented in Game.bind().
