// Menu, lobby and HUD UI bindings are implemented in main.js and Game.updateHud().
