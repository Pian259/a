// Client-side weapon presentation/stat definitions are in game.js; server owns authoritative combat values.
