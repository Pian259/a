// Rendering is implemented in Game.render() to keep the Canvas draw loop allocation-light.
