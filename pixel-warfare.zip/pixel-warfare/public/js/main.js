(() => {
const $=id=>document.getElementById(id), panels=["menu","setup","settings","about","gameScreen"];
let socket=null,online=false,owner=false,roomCode="",mode="bots",game=null;
function show(id){panels.forEach(p=>$(p).classList.toggle("hidden",p!==id));$("pauseOverlay").classList.add("hidden");}
$("vsBtn").onclick=()=>{mode="bots";$("setupTitle").textContent="VS COMPUTER";$("botOptions").classList.remove("hidden");$("onlineOptions").classList.add("hidden");show("setup")};
$("pvpBtn").onclick=()=>{mode="online";$("setupTitle").textContent="PVP ONLINE";$("botOptions").classList.add("hidden");$("onlineOptions").classList.remove("hidden");connect();show("setup")};
$("settingsBtn").onclick=()=>show("settings");$("aboutBtn").onclick=()=>show("about");document.querySelectorAll("[data-back]").forEach(b=>b.onclick=()=>show("menu"));
$("startBots").onclick=()=>startGame({mode:"bots",map:$("botMap").value,count:+$("botCount").value,difficulty:$("difficulty").value});
function connect(){if(socket)return;socket=io();socket.on("connect",()=>$("connection").textContent="● CONNECTED");socket.on("disconnect",()=>$("connection").textContent="● DISCONNECTED");socket.on("joined",d=>{roomCode=d.code;owner=d.owner;$("lobby").classList.remove("hidden");$("lobbyCode").textContent=d.code;$("startOnline").classList.toggle("hidden",!owner);$("roomError").textContent="Bagikan kode ini kepada temanmu.";});socket.on("state",s=>{if(game&&game.mode==="online")game.remote=s;renderLobby(s);if(s.started&&!game){startGame({mode:"online"});}});socket.on("errorMsg",m=>$("roomError").textContent=m); }
function nick(){return $("nickname").value.trim().slice(0,16)||"Player"}
$("createRoom").onclick=()=>{connect();socket.emit("createRoom",{name:nick(),map:$("roomMap").value})};
$("joinRoom").onclick=()=>{connect();socket.emit("joinRoom",{name:nick(),code:$("roomCode").value})};
function renderLobby(s){$("playerList").innerHTML=s.players.map(p=>`<div class="lobby-player">${esc(p.name)} ${p.id===socket.id?"(YOU)":""} ${p.alive?"●":"○"}</div>`).join("");}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
$("startOnline").onclick=()=>socket.emit("startMatch");
socket?.on?.("state",()=>{});
function startGame(opts){if(opts.mode==="online"){if(!socket||!roomCode)return;game=new Game({mode:"online",socket});}else game=new Game(opts);$("modeLabel").textContent=opts.mode==="online"?"PVP ONLINE":"VS COMPUTER";show("gameScreen");game.start();}
$("pauseBtn").onclick=()=>{if(online)return;$("pauseOverlay").classList.remove("hidden");game.paused=true};
$("resumeBtn").onclick=()=>{$("pauseOverlay").classList.add("hidden");game.paused=false;game.last=performance.now()};
$("quitBtn").onclick=()=>{if(game)game.stop();game=null;if(socket&&roomCode){socket.disconnect();socket=null;roomCode="";}show("menu")};
$("volume").oninput=e=>window.gameVolume=+e.target.value;

window.startGame=startGame;window.getApp=()=>({$});
})();