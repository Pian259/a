// Offline bot steering, target selection and firing are implemented in Game.botAI().
