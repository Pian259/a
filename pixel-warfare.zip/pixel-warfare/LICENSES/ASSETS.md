PIXEL WARFARE ASSET & LICENSE NOTICE

All visual assets in this project are original procedural drawings generated at runtime by the included Canvas 2D code. Audio effects are synthesized at runtime using the Web Audio API. No third-party game art, sound, fonts, or commercial asset packs are bundled.

The interface optionally loads Google Fonts (Rajdhani and Share Tech Mono) from Google Fonts when internet access is available; browser/system sans-serif fallback is used otherwise. Google Fonts are distributed under their respective open font licenses. To make deployment fully offline, remove the @import line from public/style.css.

Project source code: MIT License.
