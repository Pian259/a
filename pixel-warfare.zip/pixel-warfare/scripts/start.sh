#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
PORT="${PORT:-3000}"
if [ ! -d node_modules ]; then echo "Dependency belum terpasang. Jalankan ./scripts/install.sh"; exit 1; fi
IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
echo "PIXEL WARFARE starting..."
echo "Local:   http://127.0.0.1:${PORT}"
[ -n "$IP" ] && echo "Network: http://${IP}:${PORT}"
echo "Stop with Ctrl+C"
PORT="$PORT" npm start
