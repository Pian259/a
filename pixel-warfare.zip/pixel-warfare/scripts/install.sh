#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
echo "[PIXEL WARFARE] Checking Node.js..."
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js belum terpasang. Debian: sudo apt update && sudo apt install -y nodejs npm"
  exit 1
fi
node -e 'const v=process.versions.node.split(".").map(Number);if(v[0]<18){console.error("Node.js 18+ diperlukan");process.exit(1)}'
echo "[PIXEL WARFARE] Installing dependencies..."
npm install
mkdir -p logs
test -f server/server.js && test -f public/index.html
echo "[PIXEL WARFARE] Install complete."
