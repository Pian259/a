# PIXEL WARFARE

Game shooter 2D top-down HTML5 Canvas dengan mode VS COMPUTER dan PVP ONLINE berbasis Socket.IO.

## Fitur yang tersedia
- Canvas 2D pixel-style rendering, 4 arena prosedural.
- VS Computer dengan 2–9 bot dan kesulitan EASY/NORMAL/HARD.
- AI bot bergerak, menjaga jarak, strafing, membidik, dan menembak.
- PVP room code, maksimal 10 pemain, owner dapat memulai match.
- Server mengelola movement, rate of fire, ammo, reload, projectile collision, damage, kill/death, dan respawn.
- Lima senjata, ammo/reload, sprint, keyboard/mouse/touch.
- HUD health/ammo/kills/deaths/timer dan lobby.
- Audio efek sintetis; tidak memerlukan file audio eksternal.

## Persyaratan
- Debian Linux
- Node.js 18+ dan npm
- Browser modern (Chrome/Firefox/Edge/Safari)

## Instalasi cepat
```bash
sudo apt update
sudo apt install -y nodejs npm
chmod +x INSTALL.sh START.sh scripts/*.sh
./INSTALL.sh
npm start
```
Buka `http://IP-SERVER:3000`. Untuk akses dari internet, pastikan firewall dan port forwarding mengizinkan TCP 3000, atau gunakan reverse proxy HTTPS.

Alternatif:
```bash
npm install
npm start
```

## Menjalankan sebagai service sementara
```bash
./START.sh
```
Port dapat diubah:
```bash
PORT=8080 npm start
```
Health check: `http://IP-SERVER:3000/health`.

## Apache2 reverse proxy (disarankan untuk domain/HTTPS)
Aktifkan modul:
```bash
sudo a2enmod proxy proxy_http proxy_wstunnel headers rewrite
```
Buat `/etc/apache2/sites-available/pixel-warfare.conf`:
```apache
<VirtualHost *:80>
    ServerName game.example.com
    ProxyPreserveHost On
    ProxyPass /socket.io/ ws://127.0.0.1:3000/socket.io/
    ProxyPassReverse /socket.io/ ws://127.0.0.1:3000/socket.io/
    ProxyPass / http://127.0.0.1:3000/
    ProxyPassReverse / http://127.0.0.1:3000/
    ErrorLog ${APACHE_LOG_DIR}/pixel-warfare-error.log
    CustomLog ${APACHE_LOG_DIR}/pixel-warfare-access.log combined
</VirtualHost>
```
Aktifkan:
```bash
sudo a2ensite pixel-warfare
sudo apache2ctl configtest
sudo systemctl reload apache2
```
Untuk HTTPS, pasang sertifikat TLS (misalnya Let's Encrypt/Certbot) dan gunakan VirtualHost port 443.

## Kontrol
PC: WASD bergerak, mouse bidik, klik kiri tembak, R reload, Shift sprint, tombol 1–5 ganti senjata.
HP: joystick di sisi kiri layar, area kanan untuk bidik/tembak, tombol FIRE/R/sprint.

## Multiplayer
1. Buka alamat game pada dua atau lebih browser/perangkat.
2. Pilih PVP ONLINE.
3. Host membuat room lalu membagikan kode 5 karakter.
4. Pemain lain memasukkan kode.
5. Host menekan START MATCH.
6. Maksimal 10 pemain per room.

## Catatan teknis dan batasan versi
Project ini merupakan implementasi game playable yang dapat di-host sendiri, bukan layanan matchmaking publik. Room berada di memori proses dan akan hilang saat server restart. Tidak ada akun, persistence, anti-cheat tingkat kompetitif, spectator, atau matchmaking lintas-server. Untuk produksi publik, tambahkan HTTPS, autentikasi, validasi origin, persistence, monitoring, dan pengujian beban.

Server mengirim snapshot room 20 kali/detik. Movement input dibatasi dan disimulasikan di server. Pada versi ini, client tetap menangani prediksi/visual lokal sederhana; server adalah otoritas hasil damage, ammo, projectile, kill, dan respawn pada mode online.

## Lisensi
Kode project MIT. Grafis dan efek suara dibuat prosedural oleh kode project; tidak ada paket asset pihak ketiga yang perlu diunduh. Lihat `LICENSES/ASSETS.md`.
