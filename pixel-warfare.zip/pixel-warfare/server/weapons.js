module.exports = {
  pistol:   {name:"Pistol", damage:24, rate:330, mag:12, reload:1050, speed:620, spread:.025, range:560, pellets:1},
  rifle:    {name:"Assault Rifle", damage:17, rate:105, mag:30, reload:1450, speed:760, spread:.055, range:690, pellets:1},
  smg:      {name:"SMG", damage:11, rate:68, mag:36, reload:1300, speed:700, spread:.095, range:510, pellets:1},
  shotgun:  {name:"Shotgun", damage:10, rate:650, mag:6, reload:1550, speed:590, spread:.34, range:330, pellets:7},
  sniper:   {name:"Sniper Rifle", damage:75, rate:900, mag:5, reload:1800, speed:1100, spread:.008, range:1050, pellets:1}
};