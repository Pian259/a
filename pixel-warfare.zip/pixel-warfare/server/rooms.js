const maps=require("./maps");
const rooms=new Map();
const alphabet="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
function code(){let s="";for(let i=0;i<5;i++)s+=alphabet[Math.floor(Math.random()*alphabet.length)];return s;}
function createRoom(owner,name,mapKey="desert"){let c=code();while(rooms.has(c))c=code();const room={code:c,owner,players:{},bullets:[],map:maps[mapKey]||maps.desert,mapKey,started:false,created:Date.now(),feed:[]};rooms.set(c,room);return room;}
function addPlayer(room,id,name){if(Object.keys(room.players).length>=10)return false;const spawn=()=>({x:100+Math.random()*900,y:100+Math.random()*600});const s=spawn();room.players[id]={id,name:String(name||"Player").slice(0,16),x:s.x,y:s.y,r:13,hp:100,maxHp:100,alive:true,angle:0,kills:0,deaths:0,weapon:"rifle",ammo:30,reserve:120,reloading:false,reloadAt:0,lastShot:0,respawnAt:0,bot:false};return true;}
module.exports={rooms,createRoom,addPlayer};