const W=1100,H=800;
function circleRect(x,y,r,b){const cx=Math.max(b[0],Math.min(x,b[0]+b[2])),cy=Math.max(b[1],Math.min(y,b[1]+b[3]));return (x-cx)**2+(y-cy)**2<r*r;}
function blocked(x,y,r,map){if(x<r||y<r||x>W-r||y>H-r)return true;return [...map.blocks,...map.cover].some(b=>circleRect(x,y,r,b));}
function move(p,dx,dy,map){let nx=p.x+dx,ny=p.y;if(!blocked(nx,ny,p.r,map))p.x=nx;ny=p.y+dy;if(!blocked(p.x,ny,p.r,map))p.y=ny;}
function lineBlocked(x1,y1,x2,y2,map){const n=Math.ceil(Math.hypot(x2-x1,y2-y1)/12);for(let i=1;i<n;i++){let t=i/n,x=x1+(x2-x1)*t,y=y1+(y2-y1)*t;if(map.blocks.some(b=>x>b[0]&&x<b[0]+b[2]&&y>b[1]&&y<b[1]+b[3]))return true;}return false;}
module.exports={move,blocked,lineBlocked,W,H};