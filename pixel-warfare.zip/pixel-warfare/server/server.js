const express=require("express"),http=require("http"),{Server}=require("socket.io");
const path=require("path"),{rooms,createRoom,addPlayer}=require("./rooms"),{shoot,reload,updateRoom,snapshot,addFeed}=require("./game"),weapons=require("./weapons"),maps=require("./maps"),{move}=require("./collision");
const app=express(),server=http.createServer(app),io=new Server(server,{cors:{origin:false},maxHttpBufferSize:1e5});
const PORT=Number(process.env.PORT)||3000;
app.use(express.static(path.join(__dirname,"../public")));
app.get("/health",(req,res)=>res.json({ok:true,rooms:rooms.size,uptime:process.uptime()}));
const sockets=new Map(),rate=new Map();
function limited(id){const n=Date.now(),r=rate.get(id)||{n,count:0};if(n-r.n>1000){r.n=n;r.count=0;}r.count++;rate.set(id,r);return r.count>35;}
function roomOf(s){const c=sockets.get(s.id);return c&&rooms.get(c);}
function emitRoom(room){io.to(room.code).emit("state",snapshot(room));}
function leave(s){const code=sockets.get(s.id),room=rooms.get(code);if(room){delete room.players[s.id];s.leave(code);if(!Object.keys(room.players).length)rooms.delete(code);else{if(room.owner===s.id)room.owner=Object.keys(room.players)[0];emitRoom(room);}}sockets.delete(s.id);}
io.on("connection",s=>{
 s.on("createRoom",data=>{if(limited(s.id))return;leave(s);const room=createRoom(s.id,String(data?.name||"Player"),data?.map);addPlayer(room,s.id,data?.name);sockets.set(s.id,room.code);s.join(room.code);s.emit("joined",{code:room.code,owner:true});emitRoom(room);});
 s.on("joinRoom",data=>{if(limited(s.id))return;const code=String(data?.code||"").toUpperCase().replace(/[^A-Z0-9]/g,"").slice(0,5),room=rooms.get(code);if(!room)return s.emit("errorMsg","Room tidak ditemukan.");if(room.started)return s.emit("errorMsg","Pertandingan sudah dimulai.");if(Object.keys(room.players).length>=10)return s.emit("errorMsg","Room penuh (maksimal 10 pemain).");leave(s);if(!addPlayer(room,s.id,data?.name))return;sockets.set(s.id,code);s.join(code);s.emit("joined",{code,owner:room.owner===s.id});emitRoom(room);});
 s.on("startMatch",()=>{const r=roomOf(s);if(!r||r.owner!==s.id)return;r.started=true;addFeed(r,"MATCH STARTED");emitRoom(r);});
 s.on("input",d=>{const r=roomOf(s),p=r?.players[s.id];if(!r||!r.started||!p||!p.alive||limited(s.id))return;const x=Number(d?.x)||0,y=Number(d?.y)||0,len=Math.hypot(x,y)||1,sprint=!!d?.sprint,speed=sprint?255:180;move(p,x/len*Math.min(1,Math.hypot(x,y))*speed*.05,y/len*Math.min(1,Math.hypot(x,y))*speed*.05,r.map);if(Number.isFinite(d?.angle))p.angle=d.angle;if(d?.shoot)shoot(r,p,Date.now());if(d?.reload)reload(p,Date.now());if(d?.weapon&&weapons[d.weapon]&&p.weapon!==d.weapon){p.weapon=d.weapon;p.ammo=weapons[p.weapon].mag;p.reserve=120;p.reloading=false;}});
 s.on("disconnect",()=>{leave(s);rate.delete(s.id);});
});
setInterval(()=>{const now=Date.now();for(const r of rooms.values()){if(r.started){updateRoom(r,1/20,now);emitRoom(r);}}},50);
server.listen(PORT,"0.0.0.0",()=>console.log(`PIXEL WARFARE running: http://0.0.0.0:${PORT}`));