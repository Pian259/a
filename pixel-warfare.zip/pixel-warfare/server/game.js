const weapons=require("./weapons"),{move,lineBlocked,blocked}=require("./collision"),{updateBots}=require("./bots");
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function addFeed(room,text){room.feed.unshift({text,at:Date.now()});room.feed=room.feed.slice(0,5);}
function shoot(room,p,now){
 const w=weapons[p.weapon];if(!p.alive||p.reloading||now-p.lastShot<w.rate||p.ammo<=0)return;
 p.lastShot=now;p.ammo--;
 for(let i=0;i<w.pellets;i++){let a=p.angle+(Math.random()-.5)*w.spread;room.bullets.push({id:Math.random().toString(36).slice(2),owner:p.id,x:p.x+Math.cos(a)*17,y:p.y+Math.sin(a)*17,vx:Math.cos(a)*w.speed,vy:Math.sin(a)*w.speed,damage:w.damage,range:w.range,travel:0,life:Math.min(1.7,w.range/w.speed)});}
}
function reload(p,now){const w=weapons[p.weapon];if(p.reloading||p.ammo===w.mag||p.reserve<=0)return;p.reloading=true;p.reloadAt=now+w.reload;}
function updateRoom(room,dt,now){
 for(const p of Object.values(room.players)){
  if(p.reloading&&now>=p.reloadAt){const w=weapons[p.weapon],n=Math.min(w.mag-p.ammo,p.reserve);p.ammo+=n;p.reserve-=n;p.reloading=false;}
  if(!p.alive&&now>=p.respawnAt){p.x=80+Math.random()*940;p.y=80+Math.random()*640;p.hp=100;p.alive=true;p.ammo=weapons[p.weapon].mag;p.reserve=120;}
 }
 for(const b of room.bullets){
  const step=Math.min(dt,.05);b.x+=b.vx*step;b.y+=b.vy*step;b.travel+=Math.hypot(b.vx,b.vy)*step;b.life-=step;
  if(blocked(b.x,b.y,2,room.map))b.life=0;
  if(b.life>0){for(const p of Object.values(room.players)){if(!p.alive||p.id===b.owner)continue;if(Math.hypot(p.x-b.x,p.y-b.y)<p.r+4){p.hp-=b.damage;b.life=0;if(p.hp<=0){p.hp=0;p.alive=false;p.deaths++;p.respawnAt=now+2200;const killer=room.players[b.owner];if(killer){killer.kills++;addFeed(room,`${killer.name} eliminated ${p.name}`);}else addFeed(room,`${p.name} was eliminated`);}break;}}}
 }
 room.bullets=room.bullets.filter(b=>b.life>0&&b.travel<b.range);
 updateBots(room,dt,now,shoot);
}
function snapshot(room){return {code:room.code,mapKey:room.mapKey,map:room.map,started:room.started,players:Object.values(room.players).map(p=>({...p,strafe:undefined,strafeAt:undefined})),bullets:room.bullets,feed:room.feed};}
module.exports={shoot,reload,updateRoom,snapshot,addFeed};